
  # Plataforma Low-Code Multi-Paso

  This is a code bundle for Plataforma Low-Code Multi-Paso. The original project is available at https://www.figma.com/design/d5BV6TX9l8RnegxxzUq8ZA/Plataforma-Low-Code-Multi-Paso.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  